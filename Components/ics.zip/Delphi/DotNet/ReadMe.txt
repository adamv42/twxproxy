ICS for the Microsoft .NET Framework
====================================

This is a port of the Internet Component Suite aka ICS for the 
Microsoft .NET Framework.

Warning:
--------
ICS for the Microsoft .NET Framework has been prepared using
a pre-release of Delphi 2005 for the Microsoft .NET Framework. So
there may be some minor problems with the released version you
are using. Always consult OverByte website to get latest
update !

In this version, all component are just classes. You can't
drop then on a form. You must create them by code. See for 
example FtpTst sample program, the OnCreate event handler.


Installation:
-------------

ICS is delivered as pure source code. To install it, you just 
have to unpack the zip file in the directory of your choice.
The open the project group IcsDotNet.bdsgroup and compile
all project there.


Support:
--------

There is a provate mailing list dedicated to ICS support. You
are welcom to subscribe and ask for your questions. 
To subscribe point your browser to 
    http://www.elists.org/mailman/listinfo/twsocket
and follow on screen instructions.
Please avoid direct mail sent to the author. As there are
tens of thousands of ICS user, the author can't provide free
support to individuals. Use the support mailing list where a
team, including the author, is devoted to answering questions.


--
francois.piette@overbyte.be
http://www.overbyte.be
